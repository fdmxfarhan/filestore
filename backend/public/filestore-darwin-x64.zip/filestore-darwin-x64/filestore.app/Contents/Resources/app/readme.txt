for building 32 bits architecture
npm run make -- --arch=ia32