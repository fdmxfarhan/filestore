module.exports = 'http://fileestore.ir/api/'
// module.exports = 'http://localhost:3000/api/'
// module.exports = 'http://192.168.39.148:3000/api/'
